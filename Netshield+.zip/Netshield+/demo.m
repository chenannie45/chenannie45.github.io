load oregon.mat

[idx_ns, del_ns] = Netshield(A7,100,[]);
[idx_nsp, del_nsp] = Netshiedlplus(A7,100,10,[]);